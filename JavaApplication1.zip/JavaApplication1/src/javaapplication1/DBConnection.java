package javaapplication1;


import java.sql.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER042022
 */
public class DBConnection {
    Connection con=null;
    public static Connection ConnnectionDB(){
try{   
  Class.forName("org.sqlite.JDBC"); 
  Connection con= DriverManager.getConnection("jdbc:sqlite:logindb.db");
System.out.println("successful");
return con;
} 

catch (Exception e){
  
System.out.println("fail"+e);
return null;  
}
}
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Imalka Thennakoon
 */
public class afficher_tout extends javax.swing.JFrame {

    /**
     * Creates new form ViewAllRecord
     */
    DefaultTableModel model;
    public afficher_tout() {
        initComponents();
        setIssueBookDetailsToTable();
        fillSpe();
        filldom();
        
    }
    public void fillSpe() {
    ResultSet rs=null;
              Connection con =DBConnection.ConnnectionDB();
       
       try{   
              
                  Statement st = con.createStatement();
         rs = st.executeQuery("select * from spe");
                while(rs.next()){
                    jCombSpe.addItem(rs.getString("spe"));
                }
                JOptionPane.showMessageDialog(null,"Data filled successfully");

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }
    
    
   
 
    }
    public void filldom() {
          ResultSet rs=null;
              Connection con =DBConnection.ConnnectionDB();
       
       try{   
              
                  Statement st = con.createStatement();
         rs = st.executeQuery("select * from Domaine");
                while(rs.next()){
                    jComboDom.addItem(rs.getString("dom"));
                }
                JOptionPane.showMessageDialog(null,"Data filled successfully");

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }
    
    
   
 
    }
public void setIssueBookDetailsToTable(){
        try{
           
            Connection con =DBConnection.ConnnectionDB();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from expert");
            
            while (rs.next()){
                String nom = rs.getString("nom");
                String Domaine = rs.getString("Domaine");
                String Specialite = rs.getString("Specialite");
                String candidatureType = rs.getString("candidatureType");
                String Email = rs.getString("Email");
                String Telephone = rs.getString("Telephone");
                 String Wilaya = rs.getString("Wilaya"); 
                 String CV = rs.getString("CV");
                 String Autres = rs.getString("Autres");
                Object[] obj = {nom,Domaine,Specialite,candidatureType,Email,Telephone,Wilaya,CV,Autres};  
                tbl_issueBookDetails .setModel(DbUtils.resultSetToTableModel(rs));
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
            
                model.addRow(obj);
            }
        }
        catch(Exception e){
       JOptionPane.showMessageDialog(null, "Impossible de charger les données de la base de données");
        }
    }

//clear table
  public void clearTable(){
      DefaultTableModel model = (DefaultTableModel) tbl_issueBookDetails.getModel();
      model.setRowCount(0);
  }  
  
  //fetch record using date
  public void searchboth(){
      
      try {
            Connection con =DBConnection.ConnnectionDB();
            PreparedStatement pst =con.prepareStatement("select * from expert where Domaine=? and Specialite=?" );
            pst.setString(1,jComboDom.getSelectedItem().toString() );
                   pst.setString(2,jCombSpe.getSelectedItem().toString() );

            ResultSet rs =pst.executeQuery();
            while (rs.next()){
                String nom = rs.getString("nom");
                String Domaine = rs.getString("Domaine");
                String Specialite = rs.getString("Specialite");
                String candidatureType = rs.getString("candidatureType");
                String Email = rs.getString("Email");
                String Telephone = rs.getString("Telephone");
                 String Wilaya = rs.getString("Wilaya"); 
                 String CV = rs.getString("CV");
                 String Autres = rs.getString("Autres");
                Object[] obj = {nom,Domaine,Specialite,candidatureType,Email,Telephone,Wilaya,CV,Autres};  
                tbl_issueBookDetails .setModel(DbUtils.resultSetToTableModel(rs));
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
                pst.close();
                rs.close();
            }
        }
        catch(Exception e){
       JOptionPane.showMessageDialog(null, "Impossible de charger les données de la base de données");
        }
    
  
  }  
  
  public void searchspe(){
      
      try {
            Connection con =DBConnection.ConnnectionDB();
            PreparedStatement pst =con.prepareStatement("select * from expert where  Specialite=?" );
           
                   pst.setString(1,jCombSpe.getSelectedItem().toString() );

            ResultSet rs =pst.executeQuery();
            while (rs.next()){
                String nom = rs.getString("nom");
                String Domaine = rs.getString("Domaine");
                String Specialite = rs.getString("Specialite");
                String candidatureType = rs.getString("candidatureType");
                String Email = rs.getString("Email");
                String Telephone = rs.getString("Telephone");
                 String Wilaya = rs.getString("Wilaya"); 
                 String CV = rs.getString("CV");
                 String Autres = rs.getString("Autres");
                Object[] obj = {nom,Domaine,Specialite,candidatureType,Email,Telephone,Wilaya,CV,Autres};  
                tbl_issueBookDetails .setModel(DbUtils.resultSetToTableModel(rs));
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
                pst.close();
                rs.close();
            }
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null, "Impossible de charger les données de la base de données");
        }
  }
  
  
    public void searchDom(){
      
      try {
            Connection con =DBConnection.ConnnectionDB();
            PreparedStatement pst =con.prepareStatement("select * from expert where Domaine=?" );
            pst.setString(1,jComboDom.getSelectedItem().toString() );
                   

            ResultSet rs =pst.executeQuery();
            while (rs.next()){
                String nom = rs.getString("nom");
                String Domaine = rs.getString("Domaine");
                String Specialite = rs.getString("Specialite");
                String candidatureType = rs.getString("candidatureType");
                String Email = rs.getString("Email");
                String Telephone = rs.getString("Telephone");
                 String Wilaya = rs.getString("Wilaya"); 
                 String CV = rs.getString("CV");
                 String Autres = rs.getString("Autres");
                Object[] obj = {nom,Domaine,Specialite,candidatureType,Email,Telephone,Wilaya,CV,Autres};  
                tbl_issueBookDetails .setModel(DbUtils.resultSetToTableModel(rs));
                model = (DefaultTableModel) tbl_issueBookDetails.getModel();
                model.addRow(obj);
                pst.close();
                rs.close();
            }
        }
        catch(Exception e){
        e.printStackTrace(); 
        }}
     
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        rSMaterialButtonCircle4 = new rojerusan.RSMaterialButtonCircle();
        jPanel8 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        rSMaterialButtonCircle5 = new rojerusan.RSMaterialButtonCircle();
        jCombSpe = new javax.swing.JComboBox<>();
        jComboDom = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_issueBookDetails = new rojerusan.RSTableMetro();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Literature_100px_1.png"))); // NOI18N
        jLabel12.setText("Liste d'experts");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 0, 300, 110));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 350, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 120, 350, 5));

        jLabel19.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Domaine");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Specialité");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 180, -1, -1));

        rSMaterialButtonCircle4.setBackground(new java.awt.Color(255, 51, 51));
        rSMaterialButtonCircle4.setText("Tout");
        rSMaterialButtonCircle4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonCircle4MouseClicked(evt);
            }
        });
        rSMaterialButtonCircle4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle4ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 170, 160, 50));

        jPanel8.setBackground(new java.awt.Color(255, 51, 51));
        jPanel8.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jPanel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel8MouseClicked(evt);
            }
        });
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("X");
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        jPanel8.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 30));

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 0, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 51, 51));
        jPanel3.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 17)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel1.setText("Retour");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        rSMaterialButtonCircle5.setBackground(new java.awt.Color(255, 51, 51));
        rSMaterialButtonCircle5.setText("Chercher");
        rSMaterialButtonCircle5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSMaterialButtonCircle5MouseClicked(evt);
            }
        });
        rSMaterialButtonCircle5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle5ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle5, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 170, 160, 50));

        jCombSpe.setBackground(new java.awt.Color(255, 51, 51));
        jCombSpe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucune" }));
        jPanel1.add(jCombSpe, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 180, 260, -1));

        jComboDom.setBackground(new java.awt.Color(255, 51, 51));
        jComboDom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucun" }));
        jComboDom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboDomActionPerformed(evt);
            }
        });
        jPanel1.add(jComboDom, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 260, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 240));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        tbl_issueBookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Book Name", "Student Name", "Issue Date", "Due Date", "Status"
            }
        ));
        tbl_issueBookDetails.setAltoHead(35);
        tbl_issueBookDetails.setColorBackgoundHead(new java.awt.Color(0, 102, 153));
        tbl_issueBookDetails.setColorBordeFilas(new java.awt.Color(0, 102, 153));
        tbl_issueBookDetails.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        tbl_issueBookDetails.setColorSelBackgound(new java.awt.Color(255, 51, 51));
        tbl_issueBookDetails.setFont(new java.awt.Font("Yu Gothic Light", 0, 18)); // NOI18N
        tbl_issueBookDetails.setFuenteFilas(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        tbl_issueBookDetails.setFuenteFilasSelect(new java.awt.Font("Yu Gothic UI Light", 1, 14)); // NOI18N
        tbl_issueBookDetails.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 16)); // NOI18N
        tbl_issueBookDetails.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tbl_issueBookDetails.setRowHeight(25);
        tbl_issueBookDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_issueBookDetailsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_issueBookDetails);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(85, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 1200, 480));

        setSize(new java.awt.Dimension(1200, 715));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rSMaterialButtonCircle4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle4MouseClicked
        clearTable();
        setIssueBookDetailsToTable();
    }//GEN-LAST:event_rSMaterialButtonCircle4MouseClicked

    private void rSMaterialButtonCircle4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle4ActionPerformed
      
       
    }//GEN-LAST:event_rSMaterialButtonCircle4ActionPerformed

    private void tbl_issueBookDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_issueBookDetailsMouseClicked
        
    }//GEN-LAST:event_tbl_issueBookDetailsMouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        Home1 home = new Home1();
        home.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void rSMaterialButtonCircle5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle5MouseClicked
       String spe= jCombSpe.getSelectedItem().toString();
       String dom= jComboDom.getSelectedItem().toString();    
        clearTable();
        
        if ((spe.equals("Aucune"))&&(dom.equals("Aucun")))
        { JOptionPane.showMessageDialog(null,"n'oubliez pas de remplire la specialaité et le domaine");}
         if ((!spe.equals("Aucune"))&&(dom.equals("Aucun")))
        { searchspe();}
          if ((spe.equals("Aucune"))&&(!dom.equals("Aucun")))
        { searchDom();}
         if ((!spe.equals("Aucune"))&&(!dom.equals("Aucun")))
        { searchboth();}
        
        

         
    }//GEN-LAST:event_rSMaterialButtonCircle5MouseClicked

    private void rSMaterialButtonCircle5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSMaterialButtonCircle5ActionPerformed

    private void jComboDomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboDomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboDomActionPerformed

    private void jPanel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel8MouseClicked
       Home1 f=new Home1();
     f.setVisible(true);
     setVisible(false);
    }//GEN-LAST:event_jPanel8MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(afficher_tout.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(afficher_tout.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(afficher_tout.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(afficher_tout.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new afficher_tout().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jCombSpe;
    private javax.swing.JComboBox<String> jComboDom;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle4;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle5;
    private rojerusan.RSTableMetro tbl_issueBookDetails;
    // End of variables declaration//GEN-END:variables
}

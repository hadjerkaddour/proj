/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;


import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author User
 */
public class addExpert extends javax.swing.JFrame {
Connection conn =null;
 int m=1;
  PreparedStatement pst=null;
  ResultSet rs=null;
    /**
     * Creates new form ManageBooks
     */
    String book_name,author;
    int book_id,quantity;
    DefaultTableModel model;
    
    public addExpert() {
       try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn= DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
  
    }
    public addExpert(String msg) {
        
        
      try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn=DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
     
        txt_nom.setText(msg);
    }
    void com_domaine (String mot)
            
    {  int i=0;
        String combo=txt_domaine.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_domaine.setSelectedIndex(i++);
      combo=txt_domaine.getSelectedItem().toString();  }
        
        
        
        
    }
    
     void com_spe (String mot)
            
    {  int i=0;
        String combo=txt_spe.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_spe.setSelectedIndex(i++);
      combo=txt_spe.getSelectedItem().toString();  }
    }
     
         void com_type (String mot)
            
    {  int i=0;
        String combo=txt_type.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_type.setSelectedIndex(i++);
      combo=txt_type.getSelectedItem().toString();  }
    }
     
        void com_wilaya (String mot)
            
    {  int i=0;
        String combo=txt_wilaya.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_wilaya.setSelectedIndex(i++);
      combo=txt_wilaya.getSelectedItem().toString();  }    
    }
   
    
    public void fillSpe() {
        String sql="select * from spe ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_spe.addItem(rs.getString("spe"));
                }
                

            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null,e);
            }
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
    public void filldom() {
        String sql="select * from Domaine ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_domaine.addItem(rs.getString("dom"));
                }
          

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }    
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
 
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txt_emp = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        img = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_nom = new app.bolivia.swing.JCTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txt_tel = new app.bolivia.swing.JCTextField();
        txt_email = new app.bolivia.swing.JCTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        valuetext = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        cc = new com.mommoo.flat.button.FlatButton();
        flatButton5 = new com.mommoo.flat.button.FlatButton();
        valuetext2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        flatButton2 = new com.mommoo.flat.button.FlatButton();
        txt_spe = new javax.swing.JComboBox<>();
        txt_type = new javax.swing.JComboBox<>();
        txt_wilaya = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        txt_domaine = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));

        jPanel7.setBackground(new java.awt.Color(255, 51, 51));
        jPanel7.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel5.setText("Retour");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Add_User_Group_Man_Man_50px.png"))); // NOI18N
        jLabel3.setText("Ajouter un expert");

        txt_emp.setText("emp");

        jButton3.setBackground(new java.awt.Color(236, 255, 255));
        jButton3.setForeground(new java.awt.Color(0, 101, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_google_images_20px.png"))); // NOI18N
        jButton3.setText("Ajouter la photo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        img.setBackground(new java.awt.Color(255, 255, 255));
        img.setForeground(new java.awt.Color(255, 255, 255));
        img.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_external_link_80px.png"))); // NOI18N
        img.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Plus_250px.png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(txt_emp, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jLabel3))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jLabel4))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(img, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txt_emp)))
                .addGap(60, 60, 60)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(img, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jLabel4)
                .addContainerGap(361, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 700));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 51, 51));
        jPanel4.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("X");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 30));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, -1, -1));

        txt_nom.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_nom.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_nom.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_nomFocusLost(evt);
            }
        });
        txt_nom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txt_nomMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txt_nomMouseExited(evt);
            }
        });
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        jPanel3.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 290, -1));

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 153));
        jLabel10.setText("Nom :");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 280, -1));

        jLabel9.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, 90));

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 102, 153));
        jLabel11.setText("Domaine :");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 280, -1));

        jLabel12.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, -1, 90));

        jLabel13.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 102, 153));
        jLabel13.setText("Spécialité");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, 240, -1));

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, -1, 90));

        jLabel15.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 102, 153));
        jLabel15.setText("Type de candidature :");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 240, -1));

        jLabel16.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 580, -1, 90));

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 102, 153));
        jLabel20.setText("Wilaya :");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 280, -1));

        jLabel21.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 102, 153));
        jLabel21.setText("Telephone :");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 280, -1));

        txt_tel.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_tel.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_tel.setPlaceholder("0...");
        txt_tel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_telFocusLost(evt);
            }
        });
        txt_tel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_telActionPerformed(evt);
            }
        });
        txt_tel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_telKeyTyped(evt);
            }
        });
        jPanel3.add(txt_tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 330, -1));

        txt_email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_email.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txt_email.setPlaceholder("...@gmail.com");
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });
        jPanel3.add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, 230, -1));

        jLabel22.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 102, 153));
        jLabel22.setText("E-mail :");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 280, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/imgonline-com-ua-resize-bNMkUgD897AWL0vd.jpg"))); // NOI18N
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 400, 410, 260));

        valuetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetextActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 170, -1));

        jButton2.setBackground(new java.awt.Color(51, 153, 0));
        jButton2.setForeground(new java.awt.Color(0, 101, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 180, 30, 30));

        cc.setBackground(new java.awt.Color(232, 255, 255));
        cc.setForeground(new java.awt.Color(102, 159, 255));
        cc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_document_50px_2.png"))); // NOI18N
        cc.setText("     CV et autres ");
        cc.setEnabled(false);
        cc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccActionPerformed(evt);
            }
        });
        jPanel3.add(cc, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 210, 200, 60));

        flatButton5.setBackground(new java.awt.Color(232, 255, 255));
        flatButton5.setForeground(new java.awt.Color(102, 159, 255));
        flatButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_broom_50px.png"))); // NOI18N
        flatButton5.setText("      Reinitialiser");
        flatButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flatButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(flatButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 130, 200, 60));

        valuetext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetext2ActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 170, -1));

        jButton6.setBackground(new java.awt.Color(51, 153, 0));
        jButton6.setForeground(new java.awt.Color(0, 101, 153));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 30, 30));

        flatButton2.setBackground(new java.awt.Color(232, 255, 255));
        flatButton2.setForeground(new java.awt.Color(102, 159, 255));
        flatButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_user_menu_male_50px.png"))); // NOI18N
        flatButton2.setText("Ajouter Expert");
        flatButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flatButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(flatButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 50, 200, 60));

        txt_spe.setBackground(new java.awt.Color(255, 212, 86));
        jPanel3.add(txt_spe, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 250, -1));

        txt_type.setBackground(new java.awt.Color(255, 212, 86));
        txt_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Solicité", "Non solicité" }));
        txt_type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 159, 255)));
        jPanel3.add(txt_type, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 240, -1));

        txt_wilaya.setBackground(new java.awt.Color(255, 212, 86));
        txt_wilaya.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADRAR\t", "CHELEF\t", "LAGHOUAT\t", "OUM EL BOUAGUI\t", "BATNA\t", "BEDJAYA\t", "BISKRA\t", "BECHAR\t", "BLIDA\t", "BOUIRA\t", "TAMANRASSET\t", "TEBESSA\t", "TLEMCEN\t", "TIARET\t", "TIZI OUZOU\t", "ALGER\t", "DJELFA\t", "JIJEL\t", "SETIF\t", "SAIDA\t", "SKIKDA\t", "SIDI BEL ABBES\t", "ANNABA\t", "GUELMA\t", "CONSTANTINE\t", "MEDEA\t", "MOSTAGHANEM\t", "M'SILA\t", "MASCARA\t", "OUARGLA\t", "ORAN\t", "EL BAYADH\t", "ILLIZI\t", "BORDJ BOU ARRERIDJ\t", "BOUMERDES\t", "EL TAREF\t", "TINDOUF\t", "TISSEMSILT\t", "EL OUED\t", "KHENCHELA\t", "SOUK AHRAS\t", "TIPAZA\t", "MILA\t", "AIN DEFLA\t", "NAAMA\t", "AIN TEMOUCHENT\t", "GHARDAIA\t", "GHELIZANE\t", " " }));
        jPanel3.add(txt_wilaya, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 240, -1));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, 30, 300));

        txt_domaine.setBackground(new java.awt.Color(255, 212, 86));
        txt_domaine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_domaineActionPerformed(evt);
            }
        });
        jPanel3.add(txt_domaine, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 250, -1));

        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153), 2));
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 700));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 740, 700));

        setSize(new java.awt.Dimension(1200, 700));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nomFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_nomFocusLost

    }//GEN-LAST:event_txt_nomFocusLost

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
    Home1 f=new Home1();
    
     f.setVisible(true);
    // f.af.setEnabled(true);
     setVisible(false);    
    }//GEN-LAST:event_jLabel2MouseClicked

    private void txt_telFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_telFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_telFocusLost

    private void txt_telActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_telActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_telActionPerformed

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailFocusLost

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
 Home1 f=new Home1();
     f.setVisible(true);
    // f.af.setEnabled(true);
     setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void flatButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flatButton2ActionPerformed
              try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }                      
        // TODO add your handling code here:
        if (txt_nom.getText().equals("")){
            JOptionPane.showMessageDialog(null," Vous ne pouvez pas enregister un expert sans nom ");
        }
        else{
        int p = JOptionPane.showConfirmDialog(null, "Voulez vous enregistrer cet expert?","Add Record",JOptionPane.YES_NO_OPTION);
        if(p==0){

            try {
                String sql ="insert into expert " 
                        + "(nom,Domaine,Specialite,candidatureType,"
                        + "Email,Telephone,Wilaya,"
                        + "CV,Autres,Image) values (?,?,?,?,?,?,?,?,?,?) ";

                pst=conn.prepareStatement(sql);
                pst.setString(1,txt_nom.getText());
                pst.setString(2,txt_domaine.getSelectedItem().toString());
                pst.setString(3,txt_spe.getSelectedItem().toString());
                pst.setString(4,txt_type.getSelectedItem().toString());
                pst.setString(5,txt_email.getText());
                pst.setString(6,txt_tel.getText());
                pst.setString(7,txt_wilaya.getSelectedItem().toString());
                pst.setString(8,"");
               pst.setString(9,"");
                pst.setBytes(10,person_image);
              
                
                 
             
        
                
               
                

                 ResultSet r =pst.executeQuery();
                 if(r==null){
             JOptionPane.showMessageDialog(null,"This is a duplicate");}
                 else
                 {
                cc.setEnabled(true);
                
                JOptionPane.showMessageDialog(null,"Expert enregistré");
                
                 }
            }
catch(SQLException e) 
{
  
          JOptionPane.showMessageDialog(null,"Un expert avec ce nom existe déjà!");     
           

/* present to the user a message for non unique insert */
}

catch(NullPointerException e)
{
  // Null Pointer exception occured.
}
catch(Exception e)
{
 // Other error messages
}
            finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
            Date currentDate = GregorianCalendar.getInstance().getTime();
            DateFormat df = DateFormat.getDateInstance();
            String dateString = df.format(currentDate);

            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String timeString = sdf.format(d);

            String value0 = timeString;
            String value1 = dateString;
            String val = txt_emp.getText().toString();
        
         }}
            // TODO add your handling code here:
    }//GEN-LAST:event_flatButton2ActionPerformed

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked
 search f=new search(txt_nom.getText());
     f.setVisible(true);
    // f.af.setEnabled(true);
     setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel4MouseClicked

    private void valuetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetextActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String sql=" insert into Domaine (dom) values (?);";
        try{
            pst=conn.prepareStatement(sql);
            pst.setString(1,valuetext.getText());

            pst.execute();
            //filldom();
            txt_domaine.addItem(valuetext.getText());

        }
        catch (Exception e)

        {
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void valuetext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetext2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetext2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        String sql=" insert into spe (spe) values (?);";
        try{
            pst=conn.prepareStatement(sql);
            pst.setString(1,valuetext2.getText());

            pst.execute();
         

        }
        catch (Exception e)

        {
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        }
        //fillSpe();
        txt_spe.addItem(valuetext2.getText());
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

       
JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        
        filename =f.getAbsolutePath();
        ImageIcon imageIcon = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(img.getWidth(), img.getHeight(), Image.SCALE_DEFAULT));
        img.setIcon(imageIcon);
      try {

            File image = new File(filename);
            FileInputStream fis = new FileInputStream (image);
            ByteArrayOutputStream bos= new ByteArrayOutputStream();
            byte[] buf = new byte[1024];

            for(int readNum; (readNum=fis.read(buf))!=-1; ){

                bos.write(buf,0,readNum);
            }
            person_image=bos.toByteArray();
        }

        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);

        }



            // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txt_domaineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_domaineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_domaineActionPerformed

    private void ccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccActionPerformed
             try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }    // TODO add your handling code here:

        String msg=txt_nom.getText();
        copy_File f=new copy_File(msg);
        f.setVisible(true);

        setVisible(false); // TODO add your handling code here:
    }//GEN-LAST:event_ccActionPerformed

    private void flatButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flatButton5ActionPerformed
  // TODO add your handling code here:
        
       txt_nom.setText("");
      
        txt_tel.setText("");
   
        txt_email.setText("");
     
    
       // txt_cv.setText("");
        
        //txt_autre.setText("");
        valuetext.setText("");
    
        img.setIcon(null);        // TODO add your handling code here:
    }//GEN-LAST:event_flatButton5ActionPerformed

    private void txt_nomMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_nomMouseExited

    }//GEN-LAST:event_txt_nomMouseExited

    private void txt_nomMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_nomMouseEntered

        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomMouseEntered

    private void txt_telKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_telKeyTyped
char c = evt.getKeyChar();
if(!Character.isDigit(c))
evt.consume();// TODO add your handling code here:
    }//GEN-LAST:event_txt_telKeyTyped
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(addExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(addExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(addExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(addExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new addExpert().setVisible(true);
            }
        });
    }
      private final ImageIcon format =null;
    //strin filename
    String filename = null;
    byte[] person_image = null;
    
    private String gender;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public com.mommoo.flat.button.FlatButton cc;
    private com.mommoo.flat.button.FlatButton flatButton2;
    private com.mommoo.flat.button.FlatButton flatButton5;
    private javax.swing.JLabel img;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JComboBox<String> txt_domaine;
    private app.bolivia.swing.JCTextField txt_email;
    private javax.swing.JLabel txt_emp;
    private app.bolivia.swing.JCTextField txt_nom;
    private javax.swing.JComboBox<String> txt_spe;
    private app.bolivia.swing.JCTextField txt_tel;
    private javax.swing.JComboBox<String> txt_type;
    private javax.swing.JComboBox<String> txt_wilaya;
    private javax.swing.JTextField valuetext;
    private javax.swing.JTextField valuetext2;
    // End of variables declaration//GEN-END:variables
}
